
Rails.application.routes.draw do
  root to: 'home#index'

  devise_for :usuarios
  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'

  get 'simular', to: 'fretes#simular', as: 'simular_frete'

  resources :clientes
  resources :transportadors
end
