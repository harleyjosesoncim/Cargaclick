
Rails.application.routes.draw do
  root to: 'home#index'

  devise_for :usuarios
  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'

  get '/simular', to: 'home#simular', as: 'simular'
  get '/trajetos/simular', to: 'trajetos#simular', as: 'simular_trajeto'

  post 'clientes/:id/simular_trajeto', to: 'clientes#simular_trajeto', as: 'simular_trajeto_cliente'

  resources :clientes
  resources :transportadors
end
