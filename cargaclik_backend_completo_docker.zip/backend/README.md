# CargaClik

Aplicação Rails inicial.