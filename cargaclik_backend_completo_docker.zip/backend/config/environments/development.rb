# Configurações de ambiente de desenvolvimento
Rails.application.configure do
  config.cache_classes = false
  config.eager_load = false
end
