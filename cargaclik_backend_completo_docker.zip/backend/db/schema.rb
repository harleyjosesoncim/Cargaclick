# Arquivo de schema de exemplo
