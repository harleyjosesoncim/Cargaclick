class ApplicationController < ActionController::Base
  def index
    render html: "CargaClik API em execução!"
  end
end
